# app.py
from flask import (
    Flask, render_template, request, redirect, url_for,
    send_from_directory, flash, session, abort
)
from werkzeug.utils import secure_filename
import os, uuid, json, mimetypes
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'             # CHANGE IN PRODUCTION
BASE_DIR       = os.path.dirname(__file__)
UPLOAD_FOLDER  = os.path.join(BASE_DIR, 'uploads')
USERS_FILE     = os.path.join(BASE_DIR, 'users.json')
FILES_DB_FILE  = os.path.join(BASE_DIR, 'files_db.json')
SETTINGS_FILE  = os.path.join(BASE_DIR, 'settings.json')

# ------------------------------------------------------------------------------------
# Settings ----------------------------------------------------------------------------
# ------------------------------------------------------------------------------------
def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    # defaults
    return {
        "max_file_size_mb": 40,
        "max_files_per_bundle": 5,
        "registration_open": True
    }

def save_settings(s):
    try:
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(s, f, indent=2)
    except IOError:
        pass

SETTINGS = load_settings()
app.config['MAX_CONTENT_LENGTH'] = SETTINGS['max_file_size_mb'] * 1024 * 1024

# ------------------------------------------------------------------------------------
# Utility helpers ---------------------------------------------------------------------
# ------------------------------------------------------------------------------------
def format_file_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 ** 2:
        return f"{size_bytes/1024:.1f} KB"
    return f"{size_bytes/1024/1024:.1f} MB"

def get_file_size(p: str) -> int:
    try:
        return os.path.getsize(p) if os.path.exists(p) else 0
    except Exception:
        return 0

def get_file_type(fname: str) -> str:
    mime, _ = mimetypes.guess_type(fname)
    if not mime:
        return 'Unknown'
    if mime.startswith('image/'):       return 'Image'
    if mime.startswith('video/'):       return 'Video'
    if mime.startswith('audio/'):       return 'Audio'
    if mime == 'application/pdf':       return 'PDF Document'
    if mime.startswith('text/'):        return 'Text File'
    return mime

# ------------------------------------------------------------------------------------
# Users --------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------
def load_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    # default admins
    return {
        'gdhanush270': {'password': 'ttpod123', 'role': 'admin'},
        'pavi':        {'password': '272004',   'role': 'admin'}
    }

def save_users(users):
    try:
        with open(USERS_FILE, 'w') as f:
            json.dump(users, f, indent=2)
    except IOError:
        pass

USERS        = load_users()
ADMIN_USERS  = {u for u, info in USERS.items() if info['role'] == 'admin'}

# ------------------------------------------------------------------------------------
# File-DB -----------------------------------------------------------------------------
# ------------------------------------------------------------------------------------
def load_files_db():
    if os.path.exists(FILES_DB_FILE):
        try:
            with open(FILES_DB_FILE, 'r') as f:
                db = json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}

        updated = False
        for file_id, finfo in db.items():
            if not finfo.get('is_bundle') and 'size_bytes' not in finfo:
                finfo['size_bytes'] = get_file_size(finfo.get('path', ''))
                updated = True
        if updated:
            save_files_db(db)
        return db
    return {}

def save_files_db(db):
    try:
        with open(FILES_DB_FILE, 'w') as f:
            json.dump(db, f, indent=2)
    except IOError:
        pass

file_db = load_files_db()

def allowed_file(filename: str) -> bool:
    return True   # accept all extensions – change if required

# ------------------------------------------------------------------------------------
# AUTH ROUTES -------------------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if not SETTINGS.get('registration_open', True):
        flash('Registration is currently closed.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        p = request.form.get('password', '').strip()
        c = request.form.get('confirm_password', '').strip()

        if not u or not p or not c:
            flash('All fields are required!', 'error')
            return render_template('register.html')
        if p != c:
            flash('Passwords do not match!', 'error')
            return render_template('register.html')
        if u in USERS:
            flash('Username already exists!', 'error')
            return render_template('register.html')

        USERS[u] = {'password': p, 'role': 'user'}
        save_users(USERS)
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        p = request.form.get('password', '').strip()
        user = USERS.get(u)
        if user and user['password'] == p:
            session['username'] = u
            session['role']     = user['role']
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        flash('Invalid username or password!', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('login'))

# ------------------------------------------------------------------------------------
# MAIN INDEX / UPLOAD -----------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/', methods=['GET', 'POST'])
def index():
    if 'username' not in session:
        return redirect(url_for('login'))

    username   = session['username']
    role       = session.get('role', 'user')
    show_all   = request.args.get('show_all') == '1' if role == 'admin' else False

    if request.method == 'POST':
        if 'files' not in request.files:
            flash('No file part')
            return redirect(request.url)

        files = request.files.getlist('files')
        if not files or all(f.filename == '' for f in files):
            flash('No selected files')
            return redirect(request.url)

        max_files = SETTINGS['max_files_per_bundle']
        if len(files) > max_files:
            flash(f'Maximum {max_files} files allowed')
            return redirect(request.url)

        bundle_id    = str(uuid.uuid4())
        bundle_files = []
        timestamp    = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        for file in files:
            if not allowed_file(file.filename):
                flash(f'Invalid file type: {file.filename}')
                return redirect(request.url)

            filename        = secure_filename(file.filename or "")
            file_id             = str(uuid.uuid4())
            unique_filename = f"{file_id}_{filename}"
            path            = os.path.join(UPLOAD_FOLDER, unique_filename)
            file.save(path)

            size_bytes = get_file_size(path)
            file_db[file_id] = {
                'filename': filename,
                'unique_filename': unique_filename,
                'path': path,
                'timestamp': timestamp,
                'owner': username,
                'bundle_id': bundle_id,
                'size_bytes': size_bytes
            }
            bundle_files.append(file_id)

        # store bundle meta if >1 file
        if len(bundle_files) > 1:
            total_size = sum(file_db[f]['size_bytes'] for f in bundle_files)
            file_db[bundle_id] = {
                'filename': f'Bundle of {len(bundle_files)} files',
                'files': bundle_files,
                'timestamp': timestamp,
                'owner': username,
                'is_bundle': True,
                'size_bytes': total_size
            }

        save_files_db(file_db)
        flash(f'Successfully uploaded {len(bundle_files)} file(s)!')
        return redirect(url_for('index', show_all='1' if show_all else '0'))

    # file list (filtered)
    visible_files = file_db if (role == 'admin' and show_all) else {
        file_id: info for file_id, info in file_db.items() if info.get('owner') == username
    }
    return render_template('index.html',
                           files=visible_files,
                           is_admin=(role == 'admin'),
                           show_all=show_all,
                           max_files_per_bundle=SETTINGS['max_files_per_bundle'])

# ------------------------------------------------------------------------------------
# FILE PAGES / DOWNLOAD ---------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/file/<file_id>')
def file_page(file_id):
    info = file_db.get(file_id)
    if not info:
        flash('File not found!', 'error')
        return redirect(url_for('index'))

    if info.get('is_bundle'):
        bundle_files = {}
        for child in info['files']:
            f = file_db.get(child)
            if f:
                size_b           = f.get('size_bytes', get_file_size(f.get('path', '')))
                f['size']        = format_file_size(size_b)
                f['size_bytes']  = size_b
                bundle_files[child] = f
        return render_template('bundle.html',
                               bundle_info=info,
                               files=bundle_files,
                               bundle_size=format_file_size(info['size_bytes']),
                               file_id=file_id)

    # single file
    if info.get('size_bytes') is None:
        info['size_bytes'] = get_file_size(info.get('path', ''))
        save_files_db(file_db)

    return render_template('file.html',
                           file_info=info,
                           file_id=file_id,
                           file_size=format_file_size(info['size_bytes']),
                           file_type=get_file_type(info['filename']))

@app.route('/download/<file_id>')
def download_file(file_id):
    info = file_db.get(file_id)
    if not info:
        flash('File not found!', 'error')
        return redirect(url_for('index'))
    return send_from_directory(
        UPLOAD_FOLDER,
        info['unique_filename'],
        as_attachment=True,
        download_name=info['filename']
    )

# ------------------------------------------------------------------------------------
# DELETE ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/delete/<file_id>', methods=['POST'])
def delete_file(file_id):
    if 'username' not in session:
        flash('Please login to delete files.')
        return redirect(url_for('login'))

    username  = session['username']
    role      = session.get('role', 'user')
    info      = file_db.get(file_id)
    if not info:
        flash('File already deleted or not found.')
        return redirect(url_for('index'))

    if role != 'admin' and info.get('owner') != username:
        flash('You do not have permission to delete this file.')
        return redirect(url_for('index'))

    # bundle
    if info.get('is_bundle'):
        for child in info.get('files', []):
            cinfo = file_db.get(child)
            if cinfo and os.path.exists(cinfo['path']):
                try: os.remove(cinfo['path'])
                except Exception: pass
            file_db.pop(child, None)
        file_db.pop(file_id, None)
        flash('Bundle deleted successfully!')
    else:
        try:
            if os.path.exists(info['path']):
                os.remove(info['path'])
        except Exception as e:
            flash(f'Error deleting file: {e}')
            return redirect(url_for('index'))
        file_db.pop(file_id, None)
        flash('File deleted successfully!')

    save_files_db(file_db)
    return redirect(url_for('index', show_all=request.args.get('show_all', '0')))

# Delete ALL (per-user or everything)
@app.route('/delete_all', methods=['POST'])
def delete_all():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    role     = session.get('role', 'user')
    show_all = request.args.get('show_all') == '1' if role == 'admin' else False

    targets = list(file_db.keys()) if (role == 'admin' and show_all) else [
        file_id for file_id, inf in file_db.items() if inf.get('owner') == username
    ]

    deleted = 0
    for file_id in targets:
        inf = file_db.get(file_id)
        if not inf: continue
        if not inf.get('is_bundle') and os.path.exists(inf['path']):
            try: os.remove(inf['path'])
            except Exception: pass
        file_db.pop(file_id, None)
        deleted += 1

    save_files_db(file_db)
    flash(f"Deleted {deleted} file(s) successfully!")
    return redirect(url_for('index', show_all='1' if show_all else '0'))

# ------------------------------------------------------------------------------------
# ADMIN DASHBOARD ---------------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/admin')
def admin_dashboard():
    if session.get('role') != 'admin':
        flash('Admin privileges required.', 'error')
        return redirect(url_for('index'))

    MAX_STORAGE_MB     = 500
    MAX_STORAGE_BYTES  = MAX_STORAGE_MB * 1024 * 1024

    totals = {
        'storage_used_bytes': 0,
        'file_type_stats': {},
        'user_file_counts': {},
        'user_storage_bytes': {},
        'files_by_date': {}
    }

    for file_id, inf in file_db.items():
        if inf.get('is_bundle'):
            continue
        size = inf.get('size_bytes', get_file_size(inf.get('path', '')))
        inf['size_bytes'] = size
        totals['storage_used_bytes'] += size

        # type
        ext = (inf.get('filename', '').rsplit('.', 1)[-1].lower()
               if '.' in inf.get('filename', '') else 'no ext')
        totals['file_type_stats'][ext] = totals['file_type_stats'].get(ext, 0) + 1

        # per user
        owner = inf.get('owner', 'unknown')
        totals['user_file_counts'][owner]  = totals['user_file_counts'].get(owner, 0) + 1
        totals['user_storage_bytes'][owner] = totals['user_storage_bytes'].get(owner, 0) + size

        # timeline
        date_key = inf.get('timestamp', '').split(' ')[0]
        if date_key:
            totals['files_by_date'][date_key] = totals['files_by_date'].get(date_key, 0) + 1

    save_files_db(file_db)  # persist any newly computed sizes

    storage_pct      = (totals['storage_used_bytes'] / MAX_STORAGE_BYTES) * 100
    dashboard_data   = {
        'total_files':   len([f for f in file_db.values() if not f.get('is_bundle')]),
        'total_bundles': len([f for f in file_db.values() if f.get('is_bundle')]),
        'total_users':   len(USERS),
        'storage_used':  format_file_size(totals['storage_used_bytes']),
        'storage_percentage': round(storage_pct, 1),
        'remaining_storage': format_file_size(MAX_STORAGE_BYTES - totals['storage_used_bytes']),
        'file_type_stats': totals['file_type_stats'],
        'user_file_counts': totals['user_file_counts'],
        'user_storage_usage': {u: format_file_size(b) for u, b in totals['user_storage_bytes'].items()},
        'user_storage_bytes': totals['user_storage_bytes'],
        'files_by_date': dict(sorted(totals['files_by_date'].items())),
        'max_storage_mb': MAX_STORAGE_MB
    }

    return render_template('admin_dashboard.html',
                           data=dashboard_data,
                           SETTINGS=SETTINGS)

# ------------------------------------------------------------------------------------
# ADMIN – SETTINGS --------------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/admin/settings', methods=['POST'])
def admin_update_settings():
    if session.get('role') != 'admin':
        abort(403)

    SETTINGS['max_file_size_mb']     = int(request.form.get('max_file_size_mb', SETTINGS['max_file_size_mb']))
    SETTINGS['max_files_per_bundle'] = int(request.form.get('max_files_per_bundle', SETTINGS['max_files_per_bundle']))
    SETTINGS['registration_open']    = ('registration_open' in request.form)
    save_settings(SETTINGS)

    # apply new upload cap immediately
    app.config['MAX_CONTENT_LENGTH'] = SETTINGS['max_file_size_mb'] * 1024 * 1024
    flash('Settings updated.', 'success')
    return redirect(url_for('admin_dashboard'))

# ------------------------------------------------------------------------------------
# ADMIN – USER MANAGEMENT -------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.route('/admin/create_user', methods=['POST'])
def admin_create_user():
    if session.get('role') != 'admin':
        abort(403)

    u = request.form.get('username', '').strip()
    p = request.form.get('password', '').strip()
    if not u or not p:
        flash('Username and password required.', 'error')
    elif u in USERS:
        flash('User already exists.', 'error')
    else:
        USERS[u] = {'password': p, 'role': 'user'}
        save_users(USERS)
        flash(f'User {u} created.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete_user', methods=['POST'])
def admin_delete_user():
    if session.get('role') != 'admin':
        abort(403)

    u = request.form.get('username', '').strip()
    if u in ADMIN_USERS:
        flash('Cannot delete an admin account.', 'error')
        return redirect(url_for('admin_dashboard'))
    if u not in USERS:
        flash('User not found.', 'error')
        return redirect(url_for('admin_dashboard'))

    # delete user files
    for file_id in [file_id for file_id, inf in file_db.items() if inf.get('owner') == u]:
        if not file_db[file_id].get('is_bundle') and os.path.exists(file_db[file_id]['path']):
            try: os.remove(file_db[file_id]['path'])
            except Exception: pass
        file_db.pop(file_id, None)
    save_files_db(file_db)

    USERS.pop(u, None)
    save_users(USERS)
    flash(f'User {u} deleted (files removed).', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reset_password', methods=['POST'])
def admin_reset_password():
    if session.get('role') != 'admin':
        abort(403)

    u        = request.form.get('username', '').strip()
    new_pass = request.form.get('password', '').strip()
    if not new_pass:
        flash('New password is required.', 'error')
    elif u in ADMIN_USERS:
        flash('Cannot reset admin password here.', 'error')
    elif u not in USERS:
        flash('User not found.', 'error')
    else:
        USERS[u]['password'] = new_pass
        save_users(USERS)
        flash(f'Password reset for {u}.', 'success')
    return redirect(url_for('admin_dashboard'))

# ------------------------------------------------------------------------------------
# ERROR HANDLER -----------------------------------------------------------------------
# ------------------------------------------------------------------------------------
@app.errorhandler(413)
def file_too_large(e):
    flash(f'File is too large. Maximum allowed size is {SETTINGS["max_file_size_mb"]} MB.')
    return redirect(request.url)

# ------------------------------------------------------------------------------------
# RUN ---------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------
if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True)
